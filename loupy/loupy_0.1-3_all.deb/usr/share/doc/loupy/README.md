# loupy
Loupy est un petit programme pour zoomer une région de l'écran.

Il nécessite python et python-gtk.

Déplacez simplement la souris à l'endroit souhaité pour zoomer cette
zone de l'écran.
Il est aussi possible d'utiliser le clavier : 

* flèches directionnelles : déplace la loupe dans la direction donnée
* Echap : quitte l'application
* r : recharge l'affichage si le contenu derrière la loupe a changé.
* +/- : zoom ou dézoome

